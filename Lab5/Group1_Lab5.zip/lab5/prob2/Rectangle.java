package lab5.prob2;

public final class Rectangle implements Figure{
	
	final private double width;
	final private double height;
	
	public Rectangle(double base, double height) {
		this.width = base; 
		this.height = height; 
	}

	public double getWdth() {
		return width; 
	}
	public double getHeight() {
		return height; 
	}
	@Override
	public double computeArea() {
		// TODO Auto-generated method stub
		return  width * height;
	}

}
