package lesson5.labs.prob4.extpackage;

import java.time.LocalDate;

import lesson5.labs.prob4.Customer;
import lesson5.labs.prob4.CustomerOrderFactory;
import lesson5.labs.prob4.Order;

public class Main {
	public static void main(String[] args) {

		Customer bob = CustomerOrderFactory.newCustomer("Bob");

		Order or = CustomerOrderFactory.newOrder(bob);
		CustomerOrderFactory.addItem(or, "Shirt");
		CustomerOrderFactory.addItem(or, "Laptop");

		Order or2 = CustomerOrderFactory.newOrder(bob);
		CustomerOrderFactory.addItem(or2, "Pants");
		CustomerOrderFactory.addItem(or2, "Knife set");

		CustomerOrderFactory.printOrders(bob);

	}
}
