package lab5.prob1;

public class FlyNoWay implements FlyBahavior{

	@Override
	public void fly() {
		System.out.println("Cant fly");
		
	}
}