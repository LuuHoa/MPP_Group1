package lab5.prob1;

public class Squek  implements QuackBahavior{

	@Override
	public void quack() {
		System.out.println("squeking");
		
	}

}
