package lab5.prob1;

public class RubberDuck extends Duck {
	
	public RubberDuck () {
		 flyBahaiver = new FlyNoWay() ;
		 quackBahavior = new Squek() ;
	}

	@Override
	public void display() {
		System.out.println("displaying");
		
	}

}
