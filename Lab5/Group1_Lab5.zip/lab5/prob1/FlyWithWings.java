package lab5.prob1;

public class FlyWithWings implements FlyBahavior{

	@Override
	public void fly() {
		System.out.println("Fly with wings");
		
	}

}
