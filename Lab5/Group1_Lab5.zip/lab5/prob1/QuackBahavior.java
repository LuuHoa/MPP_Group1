package lab5.prob1;

public interface QuackBahavior{
	public void quack();

}
