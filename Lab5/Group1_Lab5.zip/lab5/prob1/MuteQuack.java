package lab5.prob1;

public class MuteQuack implements QuackBahavior{

	@Override
	public void quack() {
		System.out.println("cant quack");
		
	}

}
