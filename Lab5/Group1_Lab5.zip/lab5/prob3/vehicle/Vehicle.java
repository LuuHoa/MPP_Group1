package prob3.vehicle;

public interface Vehicle {
	void startEngine();
}
