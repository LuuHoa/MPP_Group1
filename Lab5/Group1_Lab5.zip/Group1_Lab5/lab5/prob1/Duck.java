package lab5.prob1;

public  abstract class Duck  {
	FlyBahavior flyBahaiver;
	QuackBahavior quackBahavior;
	
	public void swim() {
		System.out.println("Swimming \n");
	}
	
	public void fly() {
		flyBahaiver.fly();
	}
	public void quack() {
		quackBahavior.quack();
	}
	
	public abstract void display();
}
