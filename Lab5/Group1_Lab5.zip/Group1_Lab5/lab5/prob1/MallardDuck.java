package lab5.prob1;

public class MallardDuck extends Duck {
	
	public MallardDuck () {
		 flyBahaiver = new FlyWithWings() ;
		 quackBahavior = new Quack() ;
	}

	@Override
	public void display() {
		System.out.println("display");
		
	}
}
