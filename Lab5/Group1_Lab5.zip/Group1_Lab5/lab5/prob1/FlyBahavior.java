package lab5.prob1;

public interface FlyBahavior {
	public void fly();
}
