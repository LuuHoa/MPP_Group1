package lab5.prob1;

public class RedheadDuck extends Duck {
	
	public RedheadDuck () {
		 flyBahaiver = new FlyWithWings() ;
		 quackBahavior = new Quack() ;
	}

	@Override
	public void display() {
		System.out.println("displaying");
		
	}

}
