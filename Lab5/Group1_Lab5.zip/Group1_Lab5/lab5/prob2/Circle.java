package lab5.prob2;

public final class Circle implements Figure{
	
	final private double radius;
	public static final double PI = 3.4;
	
	public Circle(double radius){
		
		this.radius = radius;
	}
	
	public double getRadius() {
		return radius;
	}

	@Override
	public double computeArea() {
		// TODO Auto-generated method stub
		return radius * radius * PI;
	}

}
