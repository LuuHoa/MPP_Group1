package lab5.prob2;



public class Main {
	public static void main(String[] args) {
		Figure[] figures = {new Circle(3), new Rectangle(3,4), new Triangle(3,5)};
		
		double sum = 0;
		
		for(Figure figure : figures) {
			sum = sum + figure.computeArea();
		}
		System.out.println("Sum of the areas = " + sum);
		
	}
}
