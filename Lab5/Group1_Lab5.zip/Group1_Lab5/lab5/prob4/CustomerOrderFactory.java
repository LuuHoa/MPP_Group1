package lesson5.labs.prob4;

import java.time.LocalDate;

public class CustomerOrderFactory {

	private CustomerOrderFactory() {

	};

	public static Customer newCustomer(String name) {
		Customer cust = new Customer(name);
		return cust;
	}

	public static Order newOrder(Customer cust) {
		Order order = Order.newOrder(cust, LocalDate.now());
		return order;
	}

	public static void addItem(Order ord, String itemName) {
		ord.addItem(itemName);
	}
	
	public static void printOrders(Customer cust) {

		System.out.println(cust.getOrders());
	}

}
