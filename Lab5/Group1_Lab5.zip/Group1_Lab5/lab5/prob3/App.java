package prob3;

import prob3.vehicle.*;
import java.util.*;

public class App {

	public static void main(String[] args) {
		List<Vehicle> lv = new ArrayList<>();
		lv.add(VehicleFactory.getVehicle("Car"));
		lv.add(VehicleFactory.getVehicle("Bus"));
		lv.add(VehicleFactory.getVehicle("Truck"));
		lv.add(VehicleFactory.getVehicle("ElectricCar"));
		
		for(Vehicle v : lv) {
			v.startEngine();
		}
	}
}
