package prob3.vehicle;

class Bus implements Vehicle {
	
	public void startEngine() {
		System.out.println("The Bus is starting its engine");
	}
}
