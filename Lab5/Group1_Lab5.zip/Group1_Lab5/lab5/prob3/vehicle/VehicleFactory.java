package prob3.vehicle;

public class VehicleFactory {
	
	private VehicleFactory() {};
	
	public static Vehicle getVehicle(String name) {
		if(name == null) return null;
		
		if(name.equals("Bus")) {
			return new Bus();
		} else if (name.equals("Truck")) {
			return new Truck();
		} else if (name.equals("Car")) {
			return new Car();
		} else if (name.equals("ElectricCar")) {
			return new ElectricCar();
		} else {
			return null;
		}
	}
}
