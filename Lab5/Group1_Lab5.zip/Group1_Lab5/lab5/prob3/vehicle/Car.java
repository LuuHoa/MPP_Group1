package prob3.vehicle;

class Car implements Vehicle {

	public void startEngine() {
		System.out.println("The Car is starting its engine");
	}
}
