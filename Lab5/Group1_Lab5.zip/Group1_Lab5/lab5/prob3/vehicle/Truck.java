package prob3.vehicle;

class Truck implements Vehicle {
	
	public void startEngine() {
		System.out.println("The Truck is starting its engine");
	}
}
