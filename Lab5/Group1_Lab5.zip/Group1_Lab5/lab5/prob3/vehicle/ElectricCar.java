package prob3.vehicle;

class ElectricCar implements Vehicle {

	public void startEngine() {
		System.out.println("The ElectricCar is starting its engine");
	}
}
