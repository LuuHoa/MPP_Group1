package lab4.prob3;

public class Hourly extends Employee {
	private double hourlyWage;
	private double hoursPerWeek;
	
	public Hourly(int empID, double hourlyWage, double hoursPerWeek) {
		super(empID);
		this.hourlyWage = hourlyWage;
		this.hoursPerWeek = hoursPerWeek;
	}
	@Override
	public double calcGrossPay(int month, int years) {
		// TODO Auto-generated method stub

		return hourlyWage * hoursPerWeek * 4;
	}

}
