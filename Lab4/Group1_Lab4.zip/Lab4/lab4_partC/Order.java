package lab4.prob3;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Order {
	private LocalDate orderDate;
	private int orderNo;
	private int orderAmount;
	//package level access
	
	public Order(LocalDate orderDate, int orderNo, int orderAmount){
		this.orderDate = orderDate;
		this.orderNo = orderNo;
		this.orderAmount = orderAmount;
	}

	public int  getOrderOnAmount(){
		return orderAmount;
	}
	public int  getOrderNo(){
		return orderNo;
	}
	public LocalDate  getOrderDate(){
		return orderDate;
	}
	public void  setOderAmount(int amount){
		this.orderAmount = amount;
	}

}
