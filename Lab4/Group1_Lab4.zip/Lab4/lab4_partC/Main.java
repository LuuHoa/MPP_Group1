package lab4.prob3;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;


public class Main {
	private static final String Employee = null;

	public static void main(String[] args) {
		//LocalDate.now()
		
		
		
		//Salaried
		Employee s1 = new Salaried(1, 5000);
		s1.print(2, 2018);
		
		
		//Hourly
		Employee h1 = new Hourly(2, 200, 100);
		h1.print(2, 2018);
		
//		Date date = new Date();
//		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		
		//Hourly Commissioned
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		String date = "16/08/2018";
		String date2 = "16/09/2018";
		LocalDate localDate = LocalDate.parse(date, formatter);
		LocalDate localDate2 = LocalDate.parse(date, formatter);
		
		
		
		Employee c1 = new Commissioned(3, 15, 3000);
		if(c1 instanceof Commissioned) {
			((Commissioned)c1).addOrder(localDate, 1,0 );
			
			int orderYear  = localDate.getYear();
			int orderMonth = localDate.getMonthValue();
			
			
			((Commissioned)c1).addNewSell(orderMonth,orderYear, 30);
			((Commissioned)c1).addNewSell(orderMonth,orderYear,40);
			((Commissioned)c1).addNewSell(orderMonth,orderYear,50);
			((Commissioned)c1).addNewSell(orderMonth,orderYear,60);
			}
		
		c1.print(8, 2018);
		

		
	
		
		
	}
}
