package lab4.prob3;

public class Salaried extends Employee{

	private double salary;
	
	public Salaried (int empId, double salary) {
		super(empId);
		this.salary = salary;
	}
	@Override
	public double calcGrossPay(int month, int years) {
		// TODO Auto-generated method stub
 
		return salary ;
	}
	

}
