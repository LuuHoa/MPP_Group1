package lab4.prob3;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



public class Commissioned extends Employee {
	
	private double commission;
	private double baseSalary;
	private List<Order> orderList;
	
	public Commissioned(int empId, double commission,double baseSalary ) {
		super(empId);
		this.commission = commission;
		this.baseSalary = baseSalary;
		
	}
	
	public void addOrder(LocalDate orderDate, int orderNo, int orderAmount) {
		if(orderList == null) {
			orderList = new ArrayList<Order>();
		}
		Order order = new Order(orderDate,  orderNo, orderAmount);
		orderList.add(order);
	}
	
	//each item of list have the total amount of order of the current month 
	// this method return the total amount of orders in this month 
	public int getOrderAmount(int month, int years) {
		for(Order order : orderList) {
			LocalDate orderDate = order.getOrderDate();
			int orderYear  = orderDate.getYear();
			int orderMonth = orderDate.getMonthValue();
			if(orderYear == years && orderMonth == month) {
				return order.getOrderOnAmount();
			}
		}
		return 0;
	}
	
	public void addNewSell(int month, int years, int amount) {
		for(Order order : orderList) {
			LocalDate orderDate = order.getOrderDate();
			int orderYear  = orderDate.getYear();
			int orderMonth = orderDate.getMonthValue();
			if(orderYear == years && orderMonth == month) {
				int currentAmount = order.getOrderOnAmount() + amount;
				 order.setOderAmount(currentAmount );
			}
		}
	
	}
	
	@Override
	public double calcGrossPay(int month, int years) {
		// TODO Auto-generated method stub
		int amount = getOrderAmount( month,years);
		double value = baseSalary + ( amount* (commission / 100));
		return value;
	}

}
