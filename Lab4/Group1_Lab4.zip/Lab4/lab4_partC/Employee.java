package lab4.prob3;

import java.time.LocalDate;

public abstract class Employee {
	private int empId;
	
	public Employee(int empId) {
		this.empId = empId;
	}
	
	public Paycheck calcCompensation(int month, int years) {
		double salary =  calcGrossPay( month,  years);
			
		double fica = salary * 0.23;
		double state = salary * 0.05;
		double local = salary * 0.01;
		double medicare = salary * 0.03;
		double socialSecurity = salary * 0.075;
		
		return new Paycheck(salary, fica, state, local,  medicare, socialSecurity ); 
	}
	
	public abstract double calcGrossPay(int month, int years);
	
	public int getEmoId() {
		return empId;
	}
	public void print(int month, int years) {
		System.out.println("Employee Id is: " + getEmoId() +"\n");
		Paycheck pay = calcCompensation(month,years);
		pay.print();
	}



}
