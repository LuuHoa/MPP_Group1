package lab4.prob3;

final public class Paycheck {
	final double grossPay;
	final double fica;
	final double state;
	final double local;
	final double medicare;
	final double socialSecurity;
	
	public Paycheck(double grossPay, double fica,double state, double local, double medicare, double socialSecurity) {
		
		this.grossPay = grossPay;
		this.fica = fica;
		this.state = state;
		this.local = local;
		this.medicare = medicare;
		this.socialSecurity = socialSecurity;
		
	}
	public void print() {
		System.out.println("grossPay is : " + grossPay + "\n" + 
				           "ficaTax is : " + fica + "\n"  + 
				           "stateTax is : " + state + "\n"  + 
				           "localTax is : " + local + "\n"  + 
				           "medicareTax is : " + medicare + "\n"  + 
				           "socialSecurityTax is : " + socialSecurity + "\n" + "\n"  + 
				           "NetPay is : " + getNetPay() + "\n" +
				           "==================================================================");
		
	}
	public double getNetPay() {
		return grossPay  - (fica +  state + local + medicare + socialSecurity);
	}

}
